// FBSU Student Service System — single-page app (hash routing, state in localStorage).
(function () {
  'use strict';

  const D = window.SSS_DATA;
  const P = D.parking;
  const KEY = 'fbsu-sss-v1';
  const $ = (sel, root = document) => root.querySelector(sel);

  /* ---------------------------------------------------------------- helpers */

  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));

  const num = (n) => Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const money = (n) => `<span class="mono">${num(n)}</span> ر.س`;
  const pad = (n) => String(n).padStart(2, '0');
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const toDate = (isoDate, time = '00:00') => new Date(`${isoDate}T${time}:00`);

  const dateFmt = new Intl.DateTimeFormat('ar-SA-u-ca-gregory-nu-latn', { weekday: 'long', day: 'numeric', month: 'long' });
  const fmtDate = (isoDate) => (isoDate === iso(new Date()) ? 'اليوم' : dateFmt.format(toDate(isoDate)));

  function fmtTime(t) {
    const [h, m] = t.split(':').map(Number);
    return `<span class="mono">${pad(h % 12 || 12)}:${pad(m)}</span> ${h < 12 ? 'ص' : 'م'}`;
  }

  function addMinutes(t, mins) {
    const [h, m] = t.split(':').map(Number);
    const total = h * 60 + m + mins;
    return `${pad(Math.floor(total / 60) % 24)}:${pad(total % 60)}`;
  }

  // Next calendar date (ISO) on which the given weekday + time is still in the future.
  function nextSlotDate(dow, time) {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + ((dow - d.getDay() + 7) % 7));
    if (toDate(iso(d), time) <= new Date()) d.setDate(d.getDate() + 7);
    return iso(d);
  }

  // Next five university working days (Sunday–Thursday) on which lastTime is still in the future.
  function workingDays(lastTime) {
    const days = [];
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    while (days.length < 5) {
      if (d.getDay() <= 4 && toDate(iso(d), lastTime) > new Date()) days.push(iso(d));
      d.setDate(d.getDate() + 1);
    }
    return days;
  }

  const fmtDuration = (mins) => (mins % 60 === 0 ? `<span class="mono">${mins / 60}</span> س` : `<span class="mono">${mins}</span> د`);

  function fmtLeft(ms) {
    const s = Math.max(0, Math.round(ms / 1000));
    return `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
  }

  const ICONS = {
    parking: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M9 17V7h4a3 3 0 0 1 0 6H9"/>',
    flex: '<path d="M20 11a8 8 0 0 0-14.5-4.5L4 8"/><path d="M4 4v4h4"/><path d="M4 13a8 8 0 0 0 14.5 4.5L20 16"/><path d="M20 20v-4h-4"/>',
    home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M10 21v-6h4v6"/>',
    tutoring: '<path d="M22 10 12 5 2 10l10 5 10-5Z"/><path d="M6 12v5c3 2.5 9 2.5 12 0v-5"/><path d="M22 10v6"/>',
    office: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    rooms: '<path d="M4 21V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v17"/><path d="M2 21h20"/><path d="M16 8h3a1 1 0 0 1 1 1v12"/><path d="M12 12v.01"/>',
    wallet: '<path d="M3 7a2 2 0 0 1 2-2h13v4"/><path d="M3 7v10a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1V10a1 1 0 0 0-1-1H5a2 2 0 0 1-2-2Z"/><path d="M17 14h.01"/>',
    bookings: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/><path d="m9 15 2 2 4-4"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5Z"/>',
    logout: '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3"/><path d="M10 17l-5-5 5-5"/><path d="M5 12h11"/>',
    check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
    pin: '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21Z"/><circle cx="12" cy="9.5" r="2.5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    arrow: '<path d="M19 12H5"/><path d="m11 6-6 6 6 6"/>',
    alert: '<path d="M12 3 2 20h20L12 3Z"/><path d="M12 10v4M12 17v.01"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.2a6.5 6.5 0 0 1 3.5 5.8"/>',
    inbox: '<path d="M3 13h5l1.5 3h5L16 13h5"/><path d="M5 5h14l2 8v6H3v-6l2-8Z"/>'
  };
  const icon = (name) =>
    `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]}</svg>`;

  /* ------------------------------------------------------------------ state */

  function seed() {
    const now = new Date();
    const lab = D.rooms[0];
    const raghad = D.faculty[0];
    const officeDate = nextSlotDate(2, '11:00');
    return {
      session: null,
      theme: document.documentElement.dataset.theme || 'dark',
      seq: 9822,
      balance: 720,
      tuition: { total: 5000, paid: 1500 },
      bookings: [
        {
          id: 'BK-9801', type: 'room', ref: lab.id, key: `room:${lab.id}:seed`,
          title: lab.name, sub: 'فريق العمل: إياد الحربي، راكان المطيري، عبد العزيز السالم',
          date: iso(now), time: `${pad(now.getHours())}:${pad(now.getMinutes())}`, duration: 20,
          location: 'كلية الحاسبات وتقنية المعلومات', cost: 0, status: 'confirmed',
          endsAt: now.getTime() + (18 * 60 + 42) * 1000
        },
        {
          id: 'BK-9814', type: 'office', ref: raghad.id, key: `office:${raghad.id}:${officeDate}:11:00`,
          title: raghad.name, sub: 'مناقشة مشروع التخرج ومقرر Logic Design',
          date: officeDate, time: '11:00', duration: 30,
          location: raghad.location, cost: 0, status: 'confirmed'
        }
      ],
      txns: [
        { id: 'TXN-FBSU-9821', ts: now.getTime() - 2 * 864e5, label: 'مكافأة 10 ساعات تدريس — MATH 101', amount: 700, kind: 'earn' },
        { id: 'TXN-FBSU-9807', ts: now.getTime() - 6 * 864e5, label: 'حجز موقف — القطاع A', amount: -20, kind: 'parking' },
        { id: 'TXN-FBSU-9790', ts: now.getTime() - 12 * 864e5, label: 'سداد رسوم دراسية — القسط الأول', amount: -1500, kind: 'tuition' },
        { id: 'TXN-FBSU-9764', ts: now.getTime() - 20 * 864e5, label: 'مكافأة 22 ساعة تدريس — MATH 101', amount: 1540, kind: 'earn' }
      ]
    };
  }

  function load() {
    try {
      const saved = JSON.parse(localStorage.getItem(KEY));
      if (saved && Array.isArray(saved.bookings)) return saved;
    } catch (e) { /* storage unavailable or corrupted: fall back to demo data */ }
    return seed();
  }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* ignore */ }
  }

  let state = load();
  const ui = { tutorQuery: '', tutorCourse: 'all', bookingsTab: 'upcoming', parkSector: 'all', lastFocus: null, hadActive: false };

  const nextId = (prefix) => `${prefix}-${state.seq++}`;
  const bookingEnd = (b) => b.endsAt || toDate(b.date, b.time).getTime() + b.duration * 60000;
  const isUpcoming = (b) => b.status === 'confirmed' && bookingEnd(b) > Date.now();
  const upcoming = () => state.bookings.filter(isUpcoming)
    .sort((a, b) => toDate(a.date, a.time) - toDate(b.date, b.time));
  const isTaken = (key) => state.bookings.some((b) => b.key === key && b.status === 'confirmed');
  const activeSession = (roomId) => state.bookings.find((b) =>
    b.type === 'room' && b.status === 'confirmed' && b.endsAt && b.endsAt > Date.now() && (!roomId || b.ref === roomId));

  function addTxn(label, amount, kind) {
    const txn = { id: nextId('TXN-FBSU'), ts: Date.now(), label, amount, kind };
    state.txns.unshift(txn);
    state.balance += amount;
    return txn;
  }

  /* ----------------------------------------------------------------- toasts */

  function toast(message, kind = 'ok') {
    const el = document.createElement('div');
    el.className = `toast ${kind === 'warn' ? 'warn' : ''}`;
    el.innerHTML = `${icon(kind === 'warn' ? 'alert' : 'check')}<span>${esc(message)}</span>`;
    $('#toasts').appendChild(el);
    setTimeout(() => el.remove(), 4200);
  }

  /* ------------------------------------------------------------------ modal */

  function openModal(html) {
    ui.lastFocus = ui.lastFocus || document.activeElement;
    $('#modal-root').innerHTML =
      `<div class="modal-backdrop" data-action="backdrop"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">${html}</div></div>`;
    const first = $('#modal-root [autofocus]') || $('#modal-root input, #modal-root select, #modal-root textarea, #modal-root .modal-foot button');
    if (first) first.focus();
  }

  function closeModal() {
    $('#modal-root').innerHTML = '';
    if (ui.lastFocus && document.contains(ui.lastFocus)) ui.lastFocus.focus();
    ui.lastFocus = null;
  }

  const modalHead = (title, sub) => `
    <div class="modal-head">
      <div><h3 id="modal-title">${title}</h3>${sub ? `<p>${sub}</p>` : ''}</div>
      <button class="icon-btn" data-action="close-modal" aria-label="إغلاق">${icon('x')}</button>
    </div>`;

  const slotOption = (name, value, label, opts = {}) => `
    <label class="option">
      <input type="radio" name="${name}" value="${esc(value)}" ${opts.checked ? 'checked' : ''} ${opts.disabled ? 'disabled' : ''} required>
      <span>${label}</span>
    </label>`;

  // Radio options for weekly slots (tutors / faculty); taken slots are disabled.
  function weeklySlotOptions(type, entity) {
    let picked = false;
    return entity.slots
      .map((s) => ({ date: nextSlotDate(s.dow, s.time), time: s.time }))
      .sort((a, b) => toDate(a.date, a.time) - toDate(b.date, b.time))
      .map((s) => {
        const disabled = isTaken(`${type}:${entity.id}:${s.date}:${s.time}`);
        const checked = !disabled && !picked;
        if (checked) picked = true;
        return slotOption('slot', `${s.date}|${s.time}`,
          `${fmtDate(s.date)}<br>${fmtTime(s.time)}`, { checked, disabled });
      }).join('');
  }

  function tutoringModal(tutor) {
    openModal(`
      ${modalHead('حجز حصة تقوية', `${esc(tutor.name)} • ${esc(tutor.code)} ${esc(tutor.course)}`)}
      <form data-form="tutoring" data-ref="${tutor.id}" novalidate>
        <div class="modal-body">
          <fieldset class="field">
            <legend>اختر الموعد</legend>
            <div class="options">${weeklySlotOptions('tutoring', tutor)}</div>
          </fieldset>
          <div class="field">
            <label for="f-hours">مدة الحصة</label>
            <select class="input" id="f-hours" name="hours">
              <option value="1">ساعة واحدة</option><option value="2">ساعتان</option><option value="3">3 ساعات</option>
            </select>
          </div>
          <div class="field">
            <label for="f-note">ما الذي تريد مراجعته؟ <span class="muted">(اختياري)</span></label>
            <textarea class="input" id="f-note" name="note" maxlength="200" placeholder="مثال: مراجعة الشابتر الثالث وحل نماذج الميدتيرم"></textarea>
          </div>
          <div class="summary" id="cost-summary">${costSummary(1)}</div>
          <p class="error" id="form-error" role="alert"></p>
        </div>
        <div class="modal-foot">
          <button class="btn btn-primary" type="submit">تأكيد الحجز والخصم من الرصيد</button>
          <button class="btn btn-ghost" type="button" data-action="close-modal">إلغاء</button>
        </div>
      </form>`);
  }

  function costSummary(hours) {
    const cost = hours * D.hourRate;
    const after = state.balance - cost;
    return `
      <div class="kv"><span>التكلفة (${hours} × ${D.hourRate} ر.س)</span><strong>${money(cost)}</strong></div>
      <div class="kv"><span>الرصيد بعد الخصم</span><strong style="color:var(${after < 0 ? '--danger-text' : '--ok-text'})">${money(after)}</strong></div>`;
  }

  function officeModal(f) {
    openModal(`
      ${modalHead('حجز موعد ساعات مكتبية', `${esc(f.name)} • ${esc(f.role)}`)}
      <form data-form="office" data-ref="${f.id}" novalidate>
        <div class="modal-body">
          <fieldset class="field">
            <legend>الموعد المتاح</legend>
            <div class="options">${weeklySlotOptions('office', f)}</div>
          </fieldset>
          <fieldset class="field">
            <legend>مدة اللقاء</legend>
            <div class="options">
              ${slotOption('duration', '15', '15 دقيقة', { checked: true })}
              ${slotOption('duration', '30', '30 دقيقة')}
            </div>
          </fieldset>
          <div class="field">
            <label for="f-topic">موضوع اللقاء</label>
            <input class="input" id="f-topic" name="topic" maxlength="120" required placeholder="مثال: مناقشة مقترح مشروع التخرج">
            <span class="hint">يصل إشعار فوري إلى ${esc(f.name)} بمجرد تأكيد الحجز.</span>
          </div>
          <p class="error" id="form-error" role="alert"></p>
        </div>
        <div class="modal-foot">
          <button class="btn btn-primary" type="submit">تأكيد الموعد</button>
          <button class="btn btn-ghost" type="button" data-action="close-modal">إلغاء</button>
        </div>
      </form>`);
  }

  function roomSlotOptions(roomId, date) {
    let picked = false;
    return D.roomSlots.map((t) => {
      const disabled = isTaken(`room:${roomId}:${date}:${t}`) || toDate(date, t) <= new Date();
      const checked = !disabled && !picked;
      if (checked) picked = true;
      return slotOption('slot', t, `${fmtTime(t)}`, { checked, disabled });
    }).join('');
  }

  function roomModal(room) {
    const days = workingDays(D.roomSlots[D.roomSlots.length - 1]);
    openModal(`
      ${modalHead('حجز قاعة / معمل', `${esc(room.name)} • السعة ${room.capacity} طلاب`)}
      <form data-form="room" data-ref="${room.id}" novalidate>
        <div class="modal-body">
          <div class="field">
            <label for="f-date">اليوم</label>
            <select class="input" id="f-date" name="date">
              ${days.map((d) => `<option value="${d}">${fmtDate(d)}</option>`).join('')}
            </select>
          </div>
          <fieldset class="field">
            <legend>وقت البداية</legend>
            <div class="options" id="room-slots" style="grid-template-columns:repeat(auto-fill,minmax(96px,1fr))">${roomSlotOptions(room.id, days[0])}</div>
          </fieldset>
          <fieldset class="field">
            <legend>مدة الحجز</legend>
            <div class="options">
              ${slotOption('duration', '20', '20 دقيقة', { checked: true })}
              ${slotOption('duration', '30', '30 دقيقة')}
            </div>
            <span class="hint">الإخلاء إلزامي عند انتهاء المدة لضمان العدالة في استخدام المرافق.</span>
          </fieldset>
          <div class="field">
            <label for="f-team">أعضاء الفريق <span class="muted">(اختياري، حتى ${room.capacity - 1} زملاء)</span></label>
            <input class="input" id="f-team" name="team" maxlength="120" placeholder="مثال: راكان المطيري، عبد العزيز السالم">
          </div>
          <div class="field">
            <label for="f-purpose">الغرض من الحجز</label>
            <input class="input" id="f-purpose" name="purpose" maxlength="120" required placeholder="مثال: إنجاز واجب هندسة البرمجيات">
          </div>
          <p class="error" id="form-error" role="alert"></p>
        </div>
        <div class="modal-foot">
          <button class="btn btn-primary" type="submit">تأكيد حجز القاعة</button>
          <button class="btn btn-ghost" type="button" data-action="close-modal">إلغاء</button>
        </div>
      </form>`);
  }

  function tuitionModal() {
    const remaining = state.tuition.total - state.tuition.paid;
    const max = Math.min(state.balance, remaining);
    openModal(`
      ${modalHead('سداد الرسوم الدراسية من الرصيد', 'يُخصم المبلغ من رصيدك الجامعي ويُقيَّد مباشرة على حسابك لدى الشؤون المالية.')}
      <form data-form="tuition" novalidate>
        <div class="modal-body">
          <div class="summary" style="margin-bottom:14px">
            <div class="kv"><span>الرصيد المتاح</span><strong>${money(state.balance)}</strong></div>
            <div class="kv"><span>الرسوم المتبقية</span><strong>${money(remaining)}</strong></div>
          </div>
          <div class="field">
            <label for="f-amount">المبلغ المراد سداده (ر.س)</label>
            <input class="input mono" id="f-amount" name="amount" type="number" inputmode="decimal" min="1" max="${max}" step="0.01" value="${max}" required>
            <span class="hint">الحد الأقصى: ${num(max)} ر.س</span>
          </div>
          <p class="error" id="form-error" role="alert"></p>
        </div>
        <div class="modal-foot">
          <button class="btn btn-gold" type="submit">تأكيد السداد</button>
          <button class="btn btn-ghost" type="button" data-action="close-modal">إلغاء</button>
        </div>
      </form>`);
  }

  const receiptHtml = (txn) => `
    <div class="receipt">
      <div class="receipt-head"><span>إيصال سداد رسوم دراسية إلكتروني</span><span class="mono">${txn.id}</span></div>
      <div class="kv"><span>المستفيد</span><strong>${esc(D.student.name)} — <span class="mono">${D.student.id}</span></strong></div>
      <div class="kv"><span>المبلغ المخصوم</span><strong>${money(Math.abs(txn.amount))}</strong></div>
      <div class="kv"><span>التاريخ</span><strong>${fmtDate(iso(new Date(txn.ts)))}</strong></div>
      <div class="kv"><span>البيان</span><strong>${esc(txn.label)}</strong></div>
      <div class="ok">${icon('check')} معتمد من عمادة القبول والتسجيل والشؤون المالية</div>
    </div>`;

  function receiptModal(txn) {
    openModal(`
      ${modalHead('إيصال السداد')}
      <div class="modal-body">${receiptHtml(txn)}</div>
      <div class="modal-foot">
        <button class="btn btn-primary" data-action="print">طباعة الإيصال</button>
        <button class="btn btn-ghost" data-action="close-modal">إغلاق</button>
      </div>`);
  }

  function successModal(b, title = 'تم تأكيد الحجز') {
    openModal(`
      ${modalHead(title)}
      <div class="modal-body">
        <div class="success-mark">${icon('check')}</div>
        <div class="summary">
          <div class="kv"><span>رقم الحجز</span><strong class="mono">${b.id}</strong></div>
          <div class="kv"><span>الخدمة</span><strong>${esc(b.title)}</strong></div>
          <div class="kv"><span>الموعد</span><strong>${fmtDate(b.date)} — ${fmtTime(b.time)}</strong></div>
          <div class="kv"><span>المدة</span><strong>${fmtDuration(b.duration)}</strong></div>
          <div class="kv"><span>المكان</span><strong>${esc(b.location)}</strong></div>
          ${b.cost ? `<div class="kv"><span>المبلغ المخصوم</span><strong>${money(b.cost)}</strong></div>` : ''}
          ${b.type === 'parking' ? `<div class="kv"><span>المركبة</span><strong>${esc(b.sub)}</strong></div>` : ''}
        </div>
        ${b.type === 'parking' ? '<p class="hint" style="margin-top:10px">يُفتح حاجز البوابة تلقائياً عند قراءة لوحة مركبتك عبر كاميرات ALPR.</p>' : ''}
      </div>
      <div class="modal-foot">
        <a class="btn btn-primary" href="#/bookings" data-action="close-modal">عرض حجوزاتي</a>
        <button class="btn btn-ghost" data-action="close-modal">تم</button>
      </div>`);
  }

  function cancelModal(b) {
    openModal(`
      ${modalHead('إلغاء الحجز؟', `${esc(b.title)} — ${fmtDate(b.date)} ${fmtTime(b.time)}`)}
      <div class="modal-body">
        <p>${b.cost ? `سيُعاد مبلغ ${money(b.cost)} إلى رصيدك الجامعي.` : 'سيُتاح الموعد لطلاب آخرين فور الإلغاء.'}</p>
      </div>
      <div class="modal-foot">
        <button class="btn btn-danger" data-action="confirm-cancel" data-id="${b.id}">نعم، إلغاء الحجز</button>
        <button class="btn btn-ghost" data-action="close-modal">تراجع</button>
      </div>`);
  }

  /* ------------------------------------------------------------------ views */

  const ROUTES = {
    dashboard: { title: 'الرئيسية', short: 'الرئيسية', icon: 'home', view: dashboardView },
    parking: { title: 'المواقف الذكية', short: 'المواقف', icon: 'parking', view: parkingView },
    tutoring: { title: 'التدريس الأقراني', short: 'التدريس', icon: 'tutoring', view: tutoringView },
    office: { title: 'الساعات المكتبية', short: 'المكتبية', icon: 'office', view: officeView },
    rooms: { title: 'القاعات والمعامل', short: 'القاعات', icon: 'rooms', view: roomsView },
    wallet: { title: 'المحفظة والرسوم', short: 'المحفظة', icon: 'wallet', view: walletView },
    bookings: { title: 'حجوزاتي', short: 'حجوزاتي', icon: 'bookings', view: bookingsView }
  };

  const currentRoute = () => {
    const name = location.hash.replace(/^#\/?/, '');
    return ROUTES[name] ? name : 'dashboard';
  };

  const TYPE_META = {
    parking: { icon: 'parking', label: 'موقف سيارة', cls: 'parking' },
    tutoring: { icon: 'tutoring', label: 'حصة تقوية', cls: '' },
    office: { icon: 'office', label: 'ساعات مكتبية', cls: 'office' },
    room: { icon: 'rooms', label: 'قاعة / معمل', cls: 'room' }
  };

  function bookingItem(b, withActions = true) {
    const meta = TYPE_META[b.type];
    const live = b.endsAt && b.endsAt > Date.now() && b.status === 'confirmed';
    const status = b.status === 'cancelled' ? '<span class="pill pill-off">ملغى</span>'
      : live ? '<span class="pill pill-busy">جلسة جارية</span>'
      : isUpcoming(b) ? '<span class="pill pill-ok">مؤكد</span>'
      : '<span class="pill pill-off">منتهٍ</span>';
    return `
      <div class="item ${b.status === 'cancelled' ? 'cancelled' : ''}">
        <div class="item-icon ${meta.cls}">${icon(meta.icon)}</div>
        <div class="item-body">
          <div class="item-title">${esc(b.title)}</div>
          <div class="item-sub">${meta.label} • ${fmtDate(b.date)} • ${fmtTime(b.time)} • ${fmtDuration(b.duration)}</div>
          <div class="item-sub">${esc(b.sub)}</div>
        </div>
        <div class="item-side">
          ${status}
          ${withActions && isUpcoming(b) && !live ? `<button class="btn btn-danger btn-sm" data-action="cancel" data-id="${b.id}">إلغاء</button>` : ''}
        </div>
      </div>`;
  }

  const emptyState = (text, href, cta) => `
    <div class="empty">${icon('inbox')}<p>${text}</p>
      ${href ? `<p style="margin-top:10px"><a class="btn btn-primary btn-sm" href="${href}">${cta}</a></p>` : ''}
    </div>`;

  function sessionTimer(b) {
    return `
      <div class="timer">
        <div>
          <div class="timer-label">الوقت المتبقي للإخلاء الإلزامي</div>
          <div class="timer-value" data-countdown>${fmtLeft(b.endsAt - Date.now())}</div>
        </div>
        <div class="timer-meta">
          <div>البداية: <strong>${fmtTime(b.time)}</strong></div>
          <div>المغادرة: <strong>${fmtTime(addMinutes(b.time, b.duration))}</strong></div>
        </div>
      </div>`;
  }

  function tuitionProgress() {
    const { total, paid } = state.tuition;
    const pct = Math.round((paid / total) * 100);
    return `
      <div class="kv"><span>إجمالي رسوم الفصل</span><strong>${money(total)}</strong></div>
      <div class="kv"><span>المُسدد</span><strong style="color:var(--ok-text)">${money(paid)} (${pct}%)</strong></div>
      <div class="kv"><span>المتبقي</span><strong>${money(total - paid)}</strong></div>
      <div class="progress" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100" aria-label="نسبة سداد الرسوم" style="margin-top:8px"><i style="width:${pct}%"></i></div>`;
  }

  function dashboardView() {
    const next = upcoming();
    const live = activeSession();
    const stats = [
      { icon: 'wallet', gold: true, value: num(state.balance), unit: 'ر.س', label: 'الرصيد الجامعي' },
      { icon: 'bookings', value: next.length, unit: '', label: 'حجوزات قادمة' },
      { icon: 'tutoring', value: D.student.tutorHours, unit: 'ساعة', label: `ساعات تدريس مكتملة — <span class="mono">${D.student.tutorCourse}</span>` },
      { icon: 'office', gold: true, value: num(state.tuition.total - state.tuition.paid), unit: 'ر.س', label: 'الرسوم الدراسية المتبقية' }
    ];
    const services = [
      { href: '#/parking', icon: 'parking', title: 'المواقف الذكية', text: `خريطة حية لـ 30 موقفاً، حجز بـ ${P.rate} ر.س للساعة، وتبادل ذكي يكسبك رصيداً.` },
      { href: '#/tutoring', icon: 'tutoring', title: 'التدريس الأقراني', text: `احجز حصة تقوية مع طالب متميز بسعر موحد ${D.hourRate} ر.س للساعة.` },
      { href: '#/office', icon: 'office', title: 'الساعات المكتبية', text: 'موعد مباشر مع العميد أو رئيسة القسم أو مكتب الإرشاد.' },
      { href: '#/rooms', icon: 'rooms', title: 'القاعات والمعامل', text: 'قاعات عمل جماعي ومعامل حاسب بفترات محددة ومؤقت إخلاء.' },
      { href: '#/wallet', icon: 'wallet', title: 'المحفظة والرسوم', text: 'حوّل رصيد التدريس إلى سداد مباشر للرسوم الدراسية.' }
    ];
    return `
      <section class="hero">
        <h2>أهلاً <span>${esc(D.student.short)}</span>، كل خدماتك الجامعية في مكان واحد</h2>
        <p>${esc(D.student.college)} • ${esc(D.student.term)}</p>
        <div class="hero-actions">
          <a class="btn btn-gold" href="#/tutoring">${icon('tutoring')} احجز حصة تقوية</a>
          <a class="btn btn-ghost" href="#/parking">${icon('parking')} احجز موقفاً</a>
          <a class="btn btn-ghost" href="#/rooms">${icon('rooms')} احجز قاعة لفريقك</a>
        </div>
      </section>

      <div class="grid grid-4">
        ${stats.map((s) => `
          <div class="card stat">
            <div class="stat-icon ${s.gold ? 'gold' : ''}">${icon(s.icon)}</div>
            <div>
              <div class="stat-value"><span class="mono">${s.value}</span> <small>${s.unit}</small></div>
              <div class="stat-label">${s.label}</div>
            </div>
          </div>`).join('')}
      </div>

      ${live ? `
        <div class="section-title"><h3>جلسة جارية الآن</h3><a class="link" href="#/rooms">إدارة الجلسة</a></div>
        <div class="card accent-busy">
          <div class="person"><div><div class="person-name">${esc(live.title)}</div><div class="item-sub">${esc(live.sub)}</div></div>
          <span class="pill pill-busy">مشغول حالياً</span></div>
          ${sessionTimer(live)}
        </div>` : ''}

      <div class="grid grid-split">
        <div>
          <div class="section-title"><h3>مواعيدك القادمة</h3><a class="link" href="#/bookings">عرض الكل</a></div>
          <div class="list">
            ${next.length ? next.slice(0, 3).map((b) => bookingItem(b, false)).join('')
              : emptyState('لا توجد مواعيد قادمة.', '#/tutoring', 'احجز أول موعد')}
          </div>
        </div>
        <div>
          <div class="section-title"><h3>سداد الرسوم الدراسية</h3><a class="link" href="#/wallet">المحفظة</a></div>
          <div class="card accent-gold">${tuitionProgress()}</div>
        </div>
      </div>

      <div class="section-title"><h3>الخدمات</h3></div>
      <div class="grid grid-auto">
        ${services.map((s) => `
          <a class="card service" href="${s.href}">
            <div class="stat-icon">${icon(s.icon)}</div>
            <h4>${s.title}</h4><p>${s.text}</p>
            <span class="go">انتقل للخدمة ${icon('arrow')}</span>
          </a>`).join('')}
      </div>`;
  }

  /* ---------------------------------------------------------------- parking */

  const spots = () => P.sectors.flatMap((sector) =>
    Array.from({ length: sector.to - sector.from + 1 }, (_, i) => ({ n: sector.from + i, sector })));
  const spotLabel = (n) => `#${pad(n)}`;
  const myParking = (n) => state.bookings.find((b) =>
    b.type === 'parking' && isUpcoming(b) && (n === undefined || b.ref === String(n)));

  function spotStatus(spot) {
    const mine = myParking(spot.n);
    if (mine) return mine.shared ? 'flex' : 'mine';
    if (spot.sector.facultyOnly) return 'faculty';
    if (P.occupied.includes(spot.n)) return 'occupied';
    return P.flex.includes(spot.n) ? 'flex' : 'available';
  }

  const SPOT_META = {
    available: { label: 'متاح الآن', hint: 'احجز الآن' },
    occupied: { label: 'مشغول', hint: 'غير متاح' },
    flex: { label: 'تبادل ذكي', hint: 'خصم ساعة' },
    mine: { label: 'محجوز لك', hint: 'عرض التصريح' },
    faculty: { label: 'أعضاء التدريس', hint: 'غير متاح للطلاب' }
  };

  // Hourly tariff with a daily cap; smart-swap bays get the first hour free.
  const parkingCost = (hours, flex) =>
    Math.max(0, Math.min(hours * P.rate, P.dailyCap) - (flex ? P.rate : 0));

  function parkingCostSummary(hours, flex) {
    const base = Math.min(hours * P.rate, P.dailyCap);
    const total = parkingCost(hours, flex);
    return `
      <div class="kv"><span>التعرفة (${hours} × ${P.rate} ر.س، بسقف يومي ${P.dailyCap} ر.س)</span><strong>${money(base)}</strong></div>
      ${flex ? `<div class="kv"><span>خصم التبادل الذكي</span><strong style="color:var(--ok-text)">− ${money(P.rate)}</strong></div>` : ''}
      <div class="kv"><span>الإجمالي المستحق</span><strong style="color:var(--gold-text)">${money(total)}</strong></div>
      <div class="kv"><span>الرصيد بعد الخصم</span><strong style="color:var(${state.balance - total < 0 ? '--danger-text' : '--ok-text'})">${money(state.balance - total)}</strong></div>`;
  }

  const parkingStartOptions = (date) => P.startHours
    .filter((t) => toDate(date, t) > new Date())
    .map((t) => `<option value="${t}">${pad(Number(t.slice(0, 2)) % 12 || 12)}:00 ${t < '12:00' ? 'ص' : 'م'}</option>`).join('');

  function parkingModal(spot, flex) {
    const days = workingDays(P.startHours[P.startHours.length - 1]);
    openModal(`
      ${modalHead(`حجز الموقف ${spotLabel(spot.n)}`, `قطاع ${spot.sector.id} — ${esc(spot.sector.name)}${flex ? ' • موقف تبادل ذكي' : ''}`)}
      <form data-form="parking" data-ref="${spot.n}" data-flex="${flex ? 1 : 0}" novalidate>
        <div class="modal-body">
          <div class="field">
            <label for="p-date">اليوم</label>
            <select class="input" id="p-date" name="date">${days.map((d) => `<option value="${d}">${fmtDate(d)}</option>`).join('')}</select>
          </div>
          <div class="grid grid-2" style="gap:12px">
            <div class="field">
              <label for="p-start">من الساعة</label>
              <select class="input" id="p-start" name="start">${parkingStartOptions(days[0])}</select>
            </div>
            <div class="field">
              <label for="p-hours">عدد الساعات</label>
              <select class="input" id="p-hours" name="hours">
                ${[1, 2, 3, 4, 5, 6, 7, 8].map((h) => `<option value="${h}" ${h === 3 ? 'selected' : ''}>${h}</option>`).join('')}
              </select>
            </div>
          </div>
          <div class="summary" style="margin-bottom:10px">
            <div class="kv"><span>المركبة المسجلة</span><strong>${esc(P.vehicle.model)}</strong></div>
            <div class="kv"><span>رقم اللوحة</span><strong style="color:var(--gold-text)">${esc(P.vehicle.plate)}</strong></div>
          </div>
          <div class="summary" id="p-cost">${parkingCostSummary(3, flex)}</div>
          <p class="error" id="form-error" role="alert"></p>
        </div>
        <div class="modal-foot">
          <button class="btn btn-primary" type="submit">تأكيد الحجز وإصدار التصريح</button>
          <button class="btn btn-ghost" type="button" data-action="close-modal">إلغاء</button>
        </div>
      </form>`);
  }

  function parkingView() {
    const all = spots().map((s) => ({ ...s, status: spotStatus(s) }));
    const count = (status) => all.filter((s) => s.status === status).length;
    const sectors = P.sectors.filter((s) => ui.parkSector === 'all' || s.id === ui.parkSector);
    const mine = myParking();
    const stats = [
      { icon: 'parking', value: all.length, label: 'إجمالي مواقف الحرم' },
      { icon: 'check', value: count('available'), label: 'مواقف شاغرة الآن' },
      { icon: 'flex', gold: true, value: count('flex'), label: 'مواقف بالتبادل الذكي' },
      { icon: 'wallet', gold: true, value: num(P.rate), unit: 'ر.س / ساعة', label: `بسقف يومي ${P.dailyCap} ر.س` }
    ];
    return `
      <div class="page-head">
        <div><h2>المخطط الرقمي المباشر لمواقف الجامعة</h2>
        <p>عرض لحظي لحالة الحساسات الأرضية وكاميرات قراءة اللوحات. اضغط على أي موقف متاح لحجزه وإصدار تصريح رقمي.</p></div>
      </div>
      <div class="grid grid-4">
        ${stats.map((s) => `
          <div class="card stat">
            <div class="stat-icon ${s.gold ? 'gold' : ''}">${icon(s.icon)}</div>
            <div><div class="stat-value"><span class="mono">${s.value}</span> <small>${s.unit || ''}</small></div>
            <div class="stat-label">${s.label}</div></div>
          </div>`).join('')}
      </div>

      <div class="section-title"><h3>خريطة المواقف</h3></div>
      <div class="toolbar">
        <button class="chip-filter" data-action="filter-sector" data-id="all" aria-pressed="${ui.parkSector === 'all'}">جميع القطاعات (${all.length})</button>
        ${P.sectors.map((s) => `<button class="chip-filter" data-action="filter-sector" data-id="${s.id}" aria-pressed="${ui.parkSector === s.id}">قطاع ${s.id} — ${esc(s.name)}</button>`).join('')}
      </div>
      <div class="legend">
        ${Object.entries(SPOT_META).map(([key, m]) => `<span><i class="dot ${key}"></i>${m.label}</span>`).join('')}
      </div>
      ${sectors.map((sector) => {
        const list = all.filter((s) => s.sector.id === sector.id);
        const free = list.filter((s) => s.status === 'available' || s.status === 'flex').length;
        return `
        <section class="sector" aria-label="قطاع ${sector.id}">
          <header class="sector-head">
            <span class="sector-id mono">${sector.id}</span>
            <h4>${esc(sector.name)}</h4>
            <span class="sector-count">${sector.facultyOnly ? 'مخصص لأعضاء هيئة التدريس' : `<span class="mono">${free}</span> متاح من <span class="mono">${list.length}</span>`}</span>
          </header>
          <div class="spots">
            ${list.map((s) => {
              const m = SPOT_META[s.status];
              const body = `
                <span class="spot-num mono">${spotLabel(s.n)}</span>
                <span class="spot-bay">${s.status === 'flex' ? icon('flex') : s.status === 'available' ? 'P' : ''}</span>
                <span class="spot-state">${m.label}</span>
                <span class="spot-hint">${m.hint}</span>`;
              return s.status === 'occupied' || s.status === 'faculty'
                ? `<div class="spot ${s.status}" aria-label="الموقف ${s.n}: ${m.label}">${body}</div>`
                : `<button class="spot ${s.status}" data-action="spot" data-id="${s.n}" aria-label="الموقف ${s.n}: ${m.label} — ${m.hint}">${body}</button>`;
            }).join('')}
          </div>
        </section>`;
      }).join('')}

      <div class="section-title"><h3>شارك واربح — التبادل الذكي</h3></div>
      <div class="grid grid-split">
        <div class="card accent-gold">
          ${mine ? `
            <div class="person">
              <div><div class="person-name">${esc(mine.title)}</div>
              <div class="item-sub">${fmtDate(mine.date)} • ${fmtTime(mine.time)} • ${fmtDuration(mine.duration)}</div></div>
              ${mine.shared ? '<span class="pill pill-gold">معروض للتبادل</span>' : '<span class="pill pill-info">محجوز لك</span>'}
            </div>
            <p class="desc">${mine.shared
              ? 'موقفك متاح الآن لزملائك في فترة غيابك، وسيعود إليك عند رجوعك.'
              : `ستغادر في البريك؟ اعرض موقفك لزميل لديه محاضرة في الوقت نفسه واكسب ${num(P.flexReward)} ر.س في رصيدك الجامعي.`}</p>
            <div class="card-foot">
              <button class="btn btn-ghost btn-sm" data-action="show-pass" data-id="${mine.id}">عرض التصريح</button>
              <button class="btn btn-gold btn-sm" data-action="share-spot" data-id="${mine.id}" ${mine.shared ? 'disabled' : ''}>${icon('flex')} اعرض موقفي للتبادل</button>
            </div>` : `
            <div class="person-name" style="margin-bottom:6px">لا يوجد لديك موقف محجوز</div>
            <p class="desc" style="margin-bottom:0">احجز موقفاً من الخريطة أولاً، ثم يمكنك عرضه للتبادل الذكي عند مغادرتك المؤقتة وكسب ${num(P.flexReward)} ر.س عن كل تبادل.</p>`}
        </div>
        <ol class="card steps">
          <li><strong>رصد الخروج</strong> تقرأ كاميرا البوابة لوحة مركبتك عند خروجك في البريك.</li>
          <li><strong>تحويل الموقف إلى تبادل ذكي</strong> يُفتح الموقف لمن لديه محاضرة في التوقيت نفسه بدل بقائه فارغاً.</li>
          <li><strong>مكافأة فورية</strong> يُضاف الرصيد إلى محفظتك ويمكن استخدامه في الرسوم أو الخدمات.</li>
        </ol>
      </div>`;
  }

  function tutorCards() {
    const q = ui.tutorQuery.trim().toLowerCase();
    const list = D.tutors.filter((t) =>
      (ui.tutorCourse === 'all' || t.code === ui.tutorCourse) &&
      (!q || `${t.name} ${t.code} ${t.course}`.toLowerCase().includes(q)));
    if (!list.length) return emptyState('لا يوجد مدرّسون مطابقون لبحثك.');
    return `<div class="grid grid-2">${list.map((t) => `
      <article class="card accent-${t.accent}">
        <div class="person">
          <div class="person-id">
            <div class="avatar ${t.accent}">${esc(t.short)}</div>
            <div>
              <div class="person-name">${esc(t.name)}</div>
              <div class="person-role">${esc(t.course)} • المعدل <span class="mono">${t.gpa} / 5.00</span></div>
            </div>
          </div>
          <span class="pill pill-gold pill-plain mono">${esc(t.code)}</span>
        </div>
        <p class="note">${esc(t.desc)}</p>
        <div class="chips">
          ${t.slots.map((s) => `<span class="chip">${fmtDate(nextSlotDate(s.dow, s.time))} ${fmtTime(s.time)}</span>`).join('')}
        </div>
        <div class="card-foot">
          <span class="loc">${icon('pin')} ${esc(t.location)}</span>
          <button class="btn btn-primary btn-sm" data-action="book-tutoring" data-id="${t.id}">احجز حصة تقوية</button>
        </div>
      </article>`).join('')}</div>`;
  }

  function tutoringView() {
    const courses = ['all', ...D.tutors.map((t) => t.code)];
    return `
      <div class="page-head">
        <div><h2>الحصص والشروحات الطلابية المعتمدة</h2>
        <p>طلاب متميزون معتمدون من الكلية. تُخصم قيمة الحصة من رصيدك الجامعي، وتتحول إيرادات المدرّس إلى رصيد لسداد الرسوم.</p></div>
        <span class="pill pill-ok">سعر موحد: ${D.hourRate} ر.س / ساعة</span>
      </div>
      <div class="toolbar">
        <div class="search">${icon('search')}
          <input class="input" type="search" id="tutor-search" value="${esc(ui.tutorQuery)}" placeholder="ابحث باسم المدرّس أو المقرر" aria-label="بحث في المدرّسين">
        </div>
        ${courses.map((c) => `<button class="chip-filter ${c === 'all' ? '' : 'mono'}" data-action="filter-course" data-id="${c}" aria-pressed="${ui.tutorCourse === c}">${c === 'all' ? 'كل المقررات' : c}</button>`).join('')}
      </div>
      <div id="tutor-list">${tutorCards()}</div>

      <div class="section-title"><h3>نشاطك كمدرّس معتمد</h3><a class="link" href="#/wallet">سجل الإيرادات</a></div>
      <div class="card accent-teal">
        <div class="person" style="margin-bottom:0">
          <div class="person-id">
            <div class="avatar">${esc(D.student.short)}</div>
            <div>
              <div class="person-name">${esc(D.student.name)} — <span class="mono">${D.student.tutorCourse}</span></div>
              <div class="person-role"><span class="mono">${D.student.tutorHours}</span> ساعة تدريس مكتملة • إجمالي الإيرادات ${money(D.student.tutorHours * D.hourRate)}</div>
            </div>
          </div>
          <span class="pill pill-ok">مدرّس نشط</span>
        </div>
      </div>`;
  }

  function officeView() {
    return `
      <div class="page-head">
        <div><h2>حجز الساعات المكتبية</h2>
        <p>مواعيد مباشرة مع قيادات الكلية ومكاتب الخدمات الأكاديمية، مع إشعار فوري للطرف الآخر عند تأكيد الحجز.</p></div>
      </div>
      <div class="grid grid-2">
        ${D.faculty.map((f) => {
          const free = f.slots.some((s) => !isTaken(`office:${f.id}:${nextSlotDate(s.dow, s.time)}:${s.time}`));
          return `
          <article class="card accent-${f.accent}">
            <div class="person">
              <div class="person-id">
                <div class="avatar lg ${f.accent}">${esc(f.initials)}</div>
                <div><div class="person-name">${esc(f.name)}</div><div class="person-role">${esc(f.role)}</div></div>
              </div>
              ${free ? '<span class="pill pill-ok">متاح للحجز</span>' : '<span class="pill pill-off">مكتمل هذا الأسبوع</span>'}
            </div>
            <p class="desc">${esc(f.desc)}</p>
            <div class="chips">
              ${f.slots.map((s) => `<span class="chip">${fmtDate(nextSlotDate(s.dow, s.time))} ${fmtTime(s.time)} - ${fmtTime(addMinutes(s.time, 30))}</span>`).join('')}
            </div>
            <div class="card-foot">
              <span class="loc">${icon('pin')} ${esc(f.location)}</span>
              <button class="btn ${f.accent === 'gold' ? 'btn-gold' : 'btn-primary'} btn-sm" data-action="book-office" data-id="${f.id}" ${free ? '' : 'disabled'}>حجز موعد (15 / 30 د)</button>
            </div>
          </article>`;
        }).join('')}
      </div>`;
  }

  function roomsView() {
    return `
      <div class="page-head">
        <div><h2>القاعات ومعامل الحاسوب</h2>
        <p>حجوزات قصيرة محددة بدقة (20 أو 30 دقيقة) مع مؤقت إخلاء إلزامي لضمان العدالة في استخدام مرافق الكلية.</p></div>
      </div>
      <div class="grid grid-2">
        ${D.rooms.map((r) => {
          const live = activeSession(r.id);
          return `
          <article class="card ${live ? 'accent-busy' : 'accent-ok'}">
            <div class="person">
              <div><div class="person-name">${esc(r.name)}</div>
              <div class="item-sub">${r.type === 'lab' ? 'معمل حاسب' : 'قاعة عمل جماعي'} • السعة ${r.capacity} طلاب</div></div>
              ${live ? '<span class="pill pill-busy">مشغول حالياً</span>' : '<span class="pill pill-ok">متاحة للحجز الآن</span>'}
            </div>
            ${live ? `
              <p class="desc">${esc(live.sub)}</p>
              ${sessionTimer(live)}
              <div class="card-foot" style="margin-top:12px">
                <span class="loc">${icon('users')} جلستك الحالية</span>
                <button class="btn btn-danger btn-sm" data-action="end-session" data-id="${live.id}">إنهاء الجلسة وإخلاء المعمل</button>
              </div>` : `
              <p class="desc">${esc(r.desc)}</p>
              <div class="chips">${r.features.map((f) => `<span class="chip">${esc(f)}</span>`).join('')}</div>
              <button class="btn btn-primary btn-block" data-action="book-room" data-id="${r.id}">احجز ${r.type === 'lab' ? 'المعمل' : 'القاعة'} لفريقك</button>`}
          </article>`;
        }).join('')}
      </div>`;
  }

  function walletView() {
    const earned = state.txns.filter((t) => t.kind === 'earn').reduce((sum, t) => sum + t.amount, 0);
    const remaining = state.tuition.total - state.tuition.paid;
    const canPay = state.balance > 0 && remaining > 0;
    return `
      <div class="page-head">
        <div><h2>المحفظة وسداد الرسوم الجامعية</h2>
        <p>وفقاً للسياسة المالية للجامعة، إيرادات التدريس تتحول إلى رصيد جامعي رسمي يُستخدم في سداد الرسوم الدراسية أو حجز الخدمات.</p></div>
      </div>
      <div class="grid grid-2">
        <div class="wallet-card">
          <div class="label">الرصيد الجامعي المتاح — ${esc(D.student.name)}</div>
          <div class="value"><span class="mono">${num(state.balance)}</span> <small>ر.س</small></div>
          <div class="wallet-meta">
            <div>إجمالي إيرادات التدريس<strong><span class="mono">${num(earned)}</span> ر.س</strong></div>
            <div>الرقم الجامعي<strong class="mono">${D.student.id}</strong></div>
          </div>
        </div>
        <div class="card accent-gold">
          <h3 style="font-size:16px;margin-bottom:8px">الرسوم الدراسية — ${esc(D.student.term)}</h3>
          ${tuitionProgress()}
          <button class="btn btn-gold btn-block" style="margin-top:14px" data-action="pay-tuition" ${canPay ? '' : 'disabled'}>
            ${remaining <= 0 ? 'تم سداد الرسوم كاملة' : 'سداد من الرصيد الجامعي'}
          </button>
        </div>
      </div>

      <div class="section-title"><h3>سجل العمليات</h3></div>
      <div class="card table-wrap">
        <table>
          <thead><tr><th>البيان</th><th>التاريخ</th><th>رقم العملية</th><th>المبلغ</th><th><span class="sr">إجراء</span></th></tr></thead>
          <tbody>
            ${state.txns.map((t) => `
              <tr>
                <td>${esc(t.label)}</td>
                <td class="muted">${fmtDate(iso(new Date(t.ts)))}</td>
                <td class="mono muted">${t.id}</td>
                <td><span class="amount ${t.amount >= 0 ? 'in' : 'out'}">${t.amount >= 0 ? '+' : '−'}${num(Math.abs(t.amount))}</span></td>
                <td>${t.kind === 'tuition' ? `<button class="btn btn-ghost btn-sm" data-action="receipt" data-id="${t.id}">الإيصال</button>` : ''}</td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>`;
  }

  function bookingsView() {
    const up = upcoming();
    const past = state.bookings.filter((b) => !isUpcoming(b))
      .sort((a, b) => toDate(b.date, b.time) - toDate(a.date, a.time));
    const list = ui.bookingsTab === 'upcoming' ? up : past;
    return `
      <div class="page-head">
        <div><p>كل مواعيدك في التدريس الأقراني والساعات المكتبية والقاعات في قائمة واحدة.</p></div>
      </div>
      <div class="tabs" role="tablist">
        <button role="tab" data-action="tab" data-id="upcoming" aria-selected="${ui.bookingsTab === 'upcoming'}">القادمة (${up.length})</button>
        <button role="tab" data-action="tab" data-id="past" aria-selected="${ui.bookingsTab === 'past'}">السابقة والملغاة (${past.length})</button>
      </div>
      <div class="list">
        ${list.length ? list.map((b) => bookingItem(b)).join('')
          : ui.bookingsTab === 'upcoming' ? emptyState('لا توجد حجوزات قادمة.', '#/dashboard', 'تصفح الخدمات')
          : emptyState('لا توجد حجوزات سابقة.')}
      </div>`;
  }

  /* ------------------------------------------------------------ shell/login */

  const themeButton = (cls = '') => `
    <button class="icon-btn ${cls}" data-action="toggle-theme" aria-label="${state.theme === 'dark' ? 'التبديل إلى الوضع النهاري' : 'التبديل إلى الوضع الليلي'}">
      ${icon(state.theme === 'dark' ? 'sun' : 'moon')}
    </button>`;

  function loginView() {
    return `
      <div class="login">
        <section class="login-art">
          <h1>نظام <span>الخدمات الطلابية</span> الموحّد</h1>
          <p>بوابة واحدة لمواقف الحرم الذكية، حصص التقوية، مواعيد أعضاء هيئة التدريس، حجز القاعات والمعامل، وسداد الرسوم من رصيدك الجامعي.</p>
          <ul>
            <li>${icon('parking')} مواقف ذكية بحجز فوري وتبادل مرن</li>
            <li>${icon('tutoring')} تدريس أقراني معتمد بسعر موحد</li>
            <li>${icon('office')} ساعات مكتبية مع إشعار فوري</li>
            <li>${icon('rooms')} قاعات ومعامل بمؤقت إخلاء</li>
            <li>${icon('wallet')} محفظة رقمية وسداد مباشر للرسوم</li>
          </ul>
        </section>
        <section class="login-panel">
          ${themeButton('login-theme')}
          <form class="login-form" data-form="login" novalidate>
            <div class="brand">
              <img src="./assets/fbsu-logo.png" alt="شعار جامعة فهد بن سلطان">
              <div><div class="brand-name">جامعة فهد بن سلطان</div><div class="brand-sub">بوابة الدخول الموحد SSO</div></div>
            </div>
            <h2>تسجيل الدخول</h2>
            <p>استخدم حسابك الجامعي للوصول إلى الخدمات.</p>
            <div class="field">
              <label for="l-id">الرقم الجامعي</label>
              <input class="input mono" id="l-id" name="sid" inputmode="numeric" autocomplete="username" placeholder="441002187" required autofocus>
            </div>
            <div class="field">
              <label for="l-pw">كلمة المرور</label>
              <input class="input" id="l-pw" name="password" type="password" autocomplete="current-password" required>
            </div>
            <p class="error" id="form-error" role="alert"></p>
            <button class="btn btn-primary btn-block" type="submit" style="margin-top:8px">دخول</button>
            <div class="demo-note">نسخة واجهات تجريبية: يقبل أي رقم جامعي (6–10 أرقام) وأي كلمة مرور، ولا تُرسل البيانات إلى أي خادم.</div>
          </form>
        </section>
      </div>`;
  }

  function shellView(route) {
    const count = upcoming().length;
    return `
      <div class="shell">
        <aside class="sidebar">
          <div class="brand">
            <img src="./assets/fbsu-logo.png" alt="">
            <div><div class="brand-name">الخدمات الطلابية</div><div class="brand-sub">جامعة فهد بن سلطان</div></div>
          </div>
          <nav class="nav" aria-label="التنقل الرئيسي">
            <div class="nav-label">القائمة</div>
            ${Object.entries(ROUTES).map(([name, r]) => `
              <a href="#/${name}" ${name === route ? 'aria-current="page"' : ''}>
                ${icon(r.icon)}<span class="full">${r.title}</span><span class="short">${r.short}</span>
                ${name === 'bookings' && count ? `<span class="count">${count}</span>` : ''}
              </a>`).join('')}
          </nav>
          <div class="sidebar-foot">
            <div class="user-card">
              <div class="avatar">${esc(D.student.short)}</div>
              <div><div class="user-name">${esc(D.student.name)}</div><div class="user-id mono">${esc(state.session.sid)}</div></div>
            </div>
            <button class="btn btn-ghost btn-sm" data-action="logout">${icon('logout')} تسجيل الخروج</button>
            <button class="link-btn" data-action="reset">إعادة ضبط البيانات التجريبية</button>
          </div>
        </aside>
        <div class="main">
          <header class="topbar">
            <div><h1>${ROUTES[route].title}</h1><div class="term">${esc(D.student.term)}</div></div>
            <div class="topbar-actions">
              <a class="balance-chip" href="#/wallet" aria-label="الرصيد الجامعي">${icon('wallet')}<span class="lbl">الرصيد</span> <span class="mono">${num(state.balance)}</span> ر.س</a>
              ${themeButton()}
              <button class="icon-btn logout-top" data-action="logout" aria-label="تسجيل الخروج">${icon('logout')}</button>
            </div>
          </header>
          <main class="page" id="main" tabindex="-1">${ROUTES[route].view()}</main>
        </div>
      </div>`;
  }

  function render() {
    document.documentElement.dataset.theme = state.theme;
    const route = currentRoute();
    $('#app').innerHTML = state.session ? shellView(route) : loginView();
    document.title = `${state.session ? ROUTES[route].title : 'تسجيل الدخول'} | الخدمات الطلابية — جامعة فهد بن سلطان`;
    ui.hadActive = Boolean(activeSession());
  }

  /* ---------------------------------------------------------------- actions */

  function confirmBooking(booking) {
    state.bookings.push(booking);
    save();
    render();
    successModal(booking);
  }

  const picked = (form, name) => (form.querySelector('[name="' + name + '"]:checked') || {}).value;
  const formError = (msg) => { $('#form-error').textContent = msg; };

  const FORMS = {
    login(form) {
      const sid = form.sid.value.trim();
      if (!/^\d{6,10}$/.test(sid)) return formError('أدخل رقماً جامعياً صحيحاً (6 إلى 10 أرقام).');
      if (!form.password.value) return formError('أدخل كلمة المرور.');
      state.session = { sid };
      save();
      render();
      toast(`مرحباً ${D.student.short}، تم تسجيل الدخول.`);
    },

    tutoring(form) {
      const tutor = D.tutors.find((t) => t.id === form.dataset.ref);
      const slot = picked(form, 'slot');
      if (!slot) return formError('اختر موعداً متاحاً.');
      const [date, time] = slot.split('|');
      const hours = Number(form.hours.value);
      const cost = hours * D.hourRate;
      if (cost > state.balance) return formError('رصيدك الجامعي لا يكفي لهذه المدة. اختر مدة أقصر.');
      const note = form.note.value.trim();
      addTxn(`حصة تقوية ${tutor.code} — ${tutor.name}`, -cost, 'tutoring');
      confirmBooking({
        id: nextId('BK'), type: 'tutoring', ref: tutor.id, key: `tutoring:${tutor.id}:${date}:${time}`,
        title: `${tutor.code} — ${tutor.name}`, sub: note || tutor.course,
        date, time, duration: hours * 60, location: tutor.location, cost, status: 'confirmed'
      });
    },

    office(form) {
      const f = D.faculty.find((x) => x.id === form.dataset.ref);
      const topic = form.topic.value.trim();
      const slot = picked(form, 'slot');
      if (!slot) return formError('اختر موعداً متاحاً.');
      if (!topic) return formError('اكتب موضوع اللقاء.');
      const [date, time] = slot.split('|');
      confirmBooking({
        id: nextId('BK'), type: 'office', ref: f.id, key: `office:${f.id}:${date}:${time}`,
        title: f.name, sub: topic, date, time, duration: Number(picked(form, 'duration')),
        location: f.location, cost: 0, status: 'confirmed'
      });
    },

    room(form) {
      const room = D.rooms.find((r) => r.id === form.dataset.ref);
      const purpose = form.purpose.value.trim();
      const team = form.team.value.trim();
      const slot = picked(form, 'slot');
      if (!slot) return formError('لا توجد فترات متاحة في هذا اليوم. اختر يوماً آخر.');
      if (!purpose) return formError('اكتب الغرض من الحجز.');
      const date = form.date.value;
      const time = slot;
      confirmBooking({
        id: nextId('BK'), type: 'room', ref: room.id, key: `room:${room.id}:${date}:${time}`,
        title: room.name, sub: team ? `${purpose} • الفريق: ${team}` : purpose,
        date, time, duration: Number(picked(form, 'duration')),
        location: 'كلية الحاسبات وتقنية المعلومات', cost: 0, status: 'confirmed'
      });
    },

    parking(form) {
      const spot = spots().find((s) => s.n === Number(form.dataset.ref));
      const date = form.date.value;
      const time = form.start.value;
      const hours = Number(form.hours.value);
      const cost = parkingCost(hours, form.dataset.flex === '1');
      const key = `parking:${spot.n}:${date}`;
      if (!time) return formError('لا توجد أوقات متاحة في هذا اليوم. اختر يوماً آخر.');
      if (isTaken(key)) return formError('لديك حجز لهذا الموقف في اليوم نفسه.');
      if (cost > state.balance) return formError('رصيدك الجامعي لا يكفي لهذه المدة.');
      const title = `موقف ${spotLabel(spot.n)} — قطاع ${spot.sector.id}`;
      if (cost) addTxn(`حجز ${title}`, -cost, 'parking');
      confirmBooking({
        id: nextId('BK'), type: 'parking', ref: String(spot.n), key,
        title, sub: `${P.vehicle.model} • ${P.vehicle.plate}`,
        date, time, duration: hours * 60, location: `قطاع ${spot.sector.id} — ${spot.sector.name}`,
        cost, status: 'confirmed'
      });
    },

    tuition(form) {
      const amount = Math.round(Number(form.amount.value) * 100) / 100;
      const max = Math.min(state.balance, state.tuition.total - state.tuition.paid);
      if (!(amount > 0)) return formError('أدخل مبلغاً أكبر من صفر.');
      if (amount > max) return formError(`المبلغ يتجاوز الحد الأقصى (${num(max)} ر.س).`);
      const txn = addTxn('سداد رسوم دراسية من رصيد التدريس', -amount, 'tuition');
      state.tuition.paid += amount;
      save();
      render();
      receiptModal(txn);
      toast('تم سداد الرسوم وإصدار الإيصال.');
    }
  };

  const ACTIONS = {
    'toggle-theme'() { state.theme = state.theme === 'dark' ? 'light' : 'dark'; save(); render(); },
    logout() { state.session = null; save(); location.hash = ''; render(); },
    reset() { const { session, theme } = state; state = seed(); state.session = session; state.theme = theme; save(); render(); toast('أُعيد ضبط البيانات التجريبية.'); },
    'close-modal'() { closeModal(); },
    backdrop(el, event) { if (event.target === el) closeModal(); },
    print() { window.print(); },
    'book-tutoring'(el) { tutoringModal(D.tutors.find((t) => t.id === el.dataset.id)); },
    'book-office'(el) { officeModal(D.faculty.find((f) => f.id === el.dataset.id)); },
    'book-room'(el) { roomModal(D.rooms.find((r) => r.id === el.dataset.id)); },
    'pay-tuition'() { tuitionModal(); },
    receipt(el) { receiptModal(state.txns.find((t) => t.id === el.dataset.id)); },
    cancel(el) { cancelModal(state.bookings.find((b) => b.id === el.dataset.id)); },
    tab(el) { ui.bookingsTab = el.dataset.id; render(); },
    'filter-course'(el) { ui.tutorCourse = el.dataset.id; render(); },
    'filter-sector'(el) { ui.parkSector = el.dataset.id; render(); },
    'show-pass'(el) { successModal(state.bookings.find((b) => b.id === el.dataset.id), 'تصريح الموقف الرقمي'); },

    spot(el) {
      const spot = spots().find((s) => s.n === Number(el.dataset.id));
      const status = spotStatus(spot);
      if (status === 'mine') return successModal(myParking(spot.n), 'تصريح الموقف الرقمي');
      parkingModal(spot, status === 'flex');
    },

    'share-spot'(el) {
      const b = state.bookings.find((x) => x.id === el.dataset.id);
      b.shared = true;
      addTxn(`مكافأة التبادل الذكي — ${b.title}`, P.flexReward, 'flex');
      save();
      render();
      toast(`عُرض موقفك للتبادل وأُضيفت مكافأة ${num(P.flexReward)} ر.س إلى رصيدك.`);
    },

    'confirm-cancel'(el) {
      const b = state.bookings.find((x) => x.id === el.dataset.id);
      b.status = 'cancelled';
      if (b.cost) addTxn(`استرداد — ${b.title}`, b.cost, 'refund');
      save();
      closeModal();
      render();
      toast(b.cost ? 'أُلغي الحجز وأُعيد المبلغ إلى رصيدك.' : 'أُلغي الحجز.');
    },

    'end-session'(el) {
      const b = state.bookings.find((x) => x.id === el.dataset.id);
      b.endsAt = Date.now();
      save();
      render();
      toast('أُنهيت الجلسة وأصبح المعمل متاحاً.');
    }
  };

  /* ----------------------------------------------------------------- events */

  document.addEventListener('click', (event) => {
    const el = event.target.closest('[data-action]');
    if (el && ACTIONS[el.dataset.action]) ACTIONS[el.dataset.action](el, event);
  });

  document.addEventListener('submit', (event) => {
    const form = event.target.closest('[data-form]');
    if (!form) return;
    event.preventDefault();
    FORMS[form.dataset.form](form);
  });

  document.addEventListener('input', (event) => {
    const t = event.target;
    if (t.id === 'tutor-search') {
      ui.tutorQuery = t.value;
      $('#tutor-list').innerHTML = tutorCards();
    } else if (t.id === 'f-hours') {
      $('#cost-summary').innerHTML = costSummary(Number(t.value));
    } else if (t.id === 'p-date') {
      $('#p-start').innerHTML = parkingStartOptions(t.value);
    } else if (t.id === 'p-hours') {
      $('#p-cost').innerHTML = parkingCostSummary(Number(t.value), t.form.dataset.flex === '1');
    } else if (t.id === 'f-date') {
      $('#room-slots').innerHTML = roomSlotOptions(t.form.dataset.ref, t.value);
    }
  });

  document.addEventListener('keydown', (event) => {
    const modal = $('#modal-root .modal');
    if (!modal) return;
    if (event.key === 'Escape') return closeModal();
    if (event.key !== 'Tab') return;
    // Keep keyboard focus inside the open dialog.
    const focusable = [...modal.querySelectorAll('a[href], button:not(:disabled), input:not(:disabled), select, textarea')];
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });

  window.addEventListener('hashchange', () => {
    render();
    window.scrollTo(0, 0);
    const main = $('#main');
    if (main && !$('#modal-root .modal')) main.focus({ preventScroll: true });
  });

  // Live evacuation countdown for active lab sessions.
  setInterval(() => {
    const live = activeSession();
    document.querySelectorAll('[data-countdown]').forEach((el) => {
      el.textContent = fmtLeft(live ? live.endsAt - Date.now() : 0);
    });
    if (ui.hadActive && !live && state.session) {
      render();
      toast('انتهى وقت الجلسة — يرجى إخلاء المعمل.', 'warn');
    }
  }, 1000);

  render();
})();
